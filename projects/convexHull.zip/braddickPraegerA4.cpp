/*
Programers: Caleb Braddick, Torin Praeger 

File Name: braddickPraegerA4.cpp

Description: A program to calculate the convex hull of a set of points 

Input: A .txt file in proper format for the program, proper format has the number of coordinate pair elements in the first line of the file 
followed by coordinate pairs seperated by a space each on their own seperate lines 

Output: The points that are contained in the convex hull and the number of iterations that n elements took is printed to the console;
the number of iterations and the number of elements are output to a .csv file called OUTPUT.csv 

*/
#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

struct Point //A struct to store the x & y values of a point
{
	int x, y; //ints to store the x & y values 
};

class Hull //A class for the functionality of finding and outputting the convex hull 
{
private:
	Point *pointsArray; //an array of Point structs, to be dynamically typed in the ctor
	ifstream file; //An ifstream object of the .txt file to be read for the point values 
	string fileName; //A string to store the name of the .txt file, input by the user on std input
	short size; //A short value to store the size of the pointsArray to be made, recieved from the first line of the .txt file
	short value; //A short to store the value of the ax + by - c equations when comparing points to the line segment 
	Point *p1; //A pointer to a point to keep track of the first point on the segment 
	Point *p2; // A pointer to a point to keep track of the second point on the segment 

	long counter = 0; //A counter for the iterations 

	vector<Point> hullArray; //A vector of points to recieve the points that are shown to be on the convex hull

	//Methods

	bool isHull(Point, Point); //Method to check a segment against all other points no on the segment 
	//and return true if the sign is all the same and false if any point has a different sign
	bool firstVal(int*, int, int, int); //Method to find the first point that is not on the segment and has a value not = 0
	bool inHull(Point); //Method that checks to see if a point is already on the convex hull and returns true if it is and false if it isn't 
	

public:
	Hull();//ctor
	~Hull() {delete (this->pointsArray);}//dtor
	void printOut();//Method to print out data and output it to the OUTPUT.csv file 
};

Hull::Hull()
/*
PRE: The code compiles 
POST: A hull object is created, the ctor takes in the values from the .txt file and dynamically allocates the pointsArray 
based on the size value that is read from the first line, then fills the Points will the x and y values read from the file,
then calls the isHull method and pushes the points that meet the hull requirements onto the hullArray vector 
*/
{
	cout << "Enter filename: ";
	cin >> this->fileName; 
	file.open(this->fileName);
	if(file.fail())
	{
	    cout<<"The file failed to open";
	    exit(-1);
	}//if
	file >> size;
	cout << size << endl;
	this->pointsArray = new Point[size];
	for (int i = 0; i <size; ++i) 
	{
	    file>>pointsArray[i].x;
	    file>>pointsArray[i].y;
	}//for

	file.close();
	for (int i = 0; i < size; i++)
	{
		for (int j = 0; j < size; j++)
		{
			p1 = (pointsArray+i);
			p2 = (pointsArray+j);
			if (i == j)
			{
				break;
			}//if
			else if ((*p1).x == (*p2).x && (*p1).y == (*p2).y)
			{
				break;
			}//elif
			if(isHull(pointsArray[i], pointsArray[j]))
			{
				if (!inHull(pointsArray[i]))
				{
					hullArray.push_back(pointsArray[i]);
				}//if
				if (!inHull(pointsArray[j]))
				{
					hullArray.push_back(pointsArray[j]);
				}//if
			}//if
		}//for
	}//for
}//Hull q	

bool Hull::isHull(Point first, Point second)
/*
PRE: Points first and second exist and contain an x & y value 
POST: A boolean value true is returned if the line segment is on the convex hull and false if it is not 
*/
{
	int a,b,c,c1,c2;//values for the calculations of the signs of points based off of the line segment 
	bool sign; // Boolean value, true if the sign found is positive and false if it's negative 
	a = second.y - first.y;
	b = first.x - second.x;
	c1 = first.x * second.y;
	c2 = second.x * first.y;
	c = c1 - c2;
	 
	int fir = 0;//Assumed first element that is workable, passed to firstVal to be changed to the actual value
	
	sign = firstVal(&fir, a, b, c);

	for (int i = fir; i < size; i++)
	{
		counter++;
		
		while((pointsArray+i) == p1 or (pointsArray+i) == p2)
		{
			i++;
		}//while
		value = (pointsArray[i].x*a) + (pointsArray[i].y*b) - c;
		if (sign)
		{
			if (value < 0)
				return false;
		}//if
		else if (!sign)
		{
			if (value > 0)
				return false;
		}//elif
	}//for
	return true;
}//isHull
//---------------------------------------------------------------------
bool Hull::firstVal(int *first, int a, int b, int c)
/*
PRE: first is a real value <= 0, a, b and c are all real ints
POST: The boolean value is returned based on the sign of the first value that is not the points on the segment or = 0
*/
{
	while((&pointsArray[*first] == p1) || (&pointsArray[*first] == p2))
		{
			(*first)++;
		}//while
	value = (pointsArray[*first].x*a) + (pointsArray[*first].y*b) - c;
	if (value > 0)
		return true;
	else if (value < 0)
		return false;
	else
	{
		(*first)++;
		return firstVal(first, a, b, c);
	}//else
}//firstVal
//---------------------------------------------------------------------
void Hull::printOut()
/*
PRE: The hullArray is filled with valid points on the convex hull
POST: The points on the convex hull are printed to the console and the number of iterations and the number of elements are output to OUTPUT.csv
*/
{
	 short track = 0; //track index of left-most point 
	 for (short a = 1; a < hullArray.size(); a++) 
	 	{ 
	 		if (hullArray[a].x < hullArray[track].x) 
	 			{ 
	 				track = a; 
	 			}//if
	 	}//for
	 for (short i = track; i < hullArray.size(); i++) 
	 	{ 
	 		cout << hullArray[i].x << ", " << hullArray[i].y << endl; 
	 	}//for
	 for (short j = 0; j < track; j++) 
	 	{ 
	 		cout << hullArray[j].x << ", " << hullArray[j].y << endl;
	 	}//for
	cout << "Number of Iterations: " << counter << " for n = " << size << endl << endl;
	ofstream fout;
	fout.open("OUTPUT.csv", ios::app);
	fout << size << ", " << counter << endl;
	fout.close();
}//printOut
//---------------------------------------------------------------------
bool Hull::inHull(Point p)
/*
PRE: The hullArray is filled with valid points on the convex hull
POST: A boolena value is returned, true if the point is in the hullArray and false if it isn't 
*/
{
	for (short i = 0; i < hullArray.size(); i++)
	{
		if (hullArray[i].x == p.x && hullArray[i].y == p.y)
			return true;
	}//for
	return false;
}//inHull

int main()
/*
PRE: The code compiles 
POST: The convex hull of the .txt file given is output to the console 
and the number of elements and the number of iterations are output to OUTPUT.csv
*/
{
	Hull myHull;
	myHull.printOut();
	return 0;
}