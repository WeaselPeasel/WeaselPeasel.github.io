#include <iostream>
#include <cstdio>
#include <random>

using namespace std;

int main()
{
	srand(time(NULL));
	FILE *fout;
	char filename[20];
	printf("Enter file name [max 20 chars]: ");
	scanf("%s", filename);
	fout = fopen(filename, "w");
	if (fout == NULL)
	{
		cout << "COULD NOT OPEN FILE. Terminating...";
		exit(-1);
	}

	short count = 0;

	printf("Enter the number of points you wish to generate: ");
	scanf("%hu", &count);
	short num;
	fprintf(fout, "%i\n", count);
	for (short i = 0; i < count; i++)
	{
		for (short i = 0; i < 2; i++)
		{
			num = rand() % 8 + 1;
			fprintf(fout, "%i ", num);
		}
		fprintf(fout, "%c", '\n');
	}
	return 0;
}