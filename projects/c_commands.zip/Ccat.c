/*
 * Ccat.c
 * Programmer: Caleb B
 * Description: prints contents of <file> to screen
 * Input: ./Ccat <file1> -b -n 
 * 		where <file1> is a file with any number of lines of any length
 * Output: <file2> contains <file1>'s contents
 * 
 * NOTE: Code as it is isn't very efficient and should be worked on more later, if possible
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void openInput(FILE**, char*);
void double_size(char**, int*);

void nProcess(char**, int, FILE** infile);
void bProcess(char**, int, FILE** infile);
void dProcess(char**, int, FILE** infile);

/*Function for parsing command line arguments*/

int main(int argc, char** argv){
	if (argc < 2){
		printf("Not enough arguments supplied\n");
		return 1;
	}
	/*Declare variables*/
	int size = 200;
	char* buffer;
	FILE* infile;
	buffer = (char*)malloc(size);

	

	if (argc == 3){
		openInput(&infile, argv[2]);
		if (strcmp(argv[1], "-n") == 0){
			nProcess(&buffer, size, &infile);
		} 
	}
	else {
		openInput(&infile, argv[1]);
		dProcess(&buffer, size, &infile);
	}

	free(buffer);
	return 0;
}
/*--------------------------------------------------------*/
void openInput(FILE** input, char* filename){
	/* Input: <input> = file pointer to open
	 * Ouput: opens file with name <filename> and checks the success of fopen()
	*/
	*input = fopen(filename, "r");
	if (!(*input)){
		printf("file: %s could not be opened\n", filename);
		exit(1);
	}
}
/*--------------------------------------------------------*/
void double_size(char** buffer, int* size){
	/* Input: <buffer>: the buffer to resize; <size>: the current size of the file
	 * Ouput: <size> is doubled and <buffer> is twice as big
	*/
	char* tmp = *buffer;
	*buffer = (char*)malloc(*size * 2);
	short i;
	for (i = 0; i < *size; i++){
		(*buffer)[i] = tmp[i];
	}
	free(tmp);
	*size = *size * 2;
}
/*--------------------------------------------------------*/
void nProcess(char** buffer, int size, FILE** infile){
	/* Input: <buffer>: the buffer to read into; <size>: the buffer size as it's passed in, <infile> is the file to read from
	 * Output: prints out the contnts of file, including line numbers
	 */
	char readin;
	int index = 0;

	readin = fgetc(*infile);
	while (readin!=EOF){
		(*buffer)[index] = readin;
		index++;
		if (index == size){
			double_size(buffer, &size);
		}
		readin = fgetc(*infile);
	}

	short i = 0;
	int linecnt = 1; /*assumes at least one line*/
	printf("%d\t", linecnt);
	for (i = 0; i < index - 1; i++){
		char printout = (*buffer)[i];
		if (printout == '\n'){
			linecnt++;
			printf("%c%d\t", printout, linecnt);
		} else {
			printf("%c", printout);
		}
	}
	printf("\n");
}
/*---------------------------------------------------------*/
void dProcess(char** buffer, int size, FILE** infile){
	/* Input: <buffer>: the character buffer to put file contents into; 
			<size>: the size of the buffer as it's passed in
			<infile>: the file to read from
	 */
	char readin;
	int index = 0;

	readin = fgetc(*infile);
	while (readin!=EOF){
		(*buffer)[index] = readin;
		index++;
		if (index == size){
			double_size(buffer, &size);
		}
		readin = fgetc(*infile);
	}
	printf("%s\n", *buffer);
}