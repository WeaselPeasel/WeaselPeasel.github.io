/* 
 * Ccat.c
 * Programmer: Caleb B
 * Description: sorts the contents of file <file> and prints the results to the screen
 * Input: ./Csort <file> -n -r -u -nr: <file> is the file to be sorted; file should have only 
 * 		one data item per line
 * Output: prints out the contents of the file, sorted
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int get_linecount(FILE*, int*);
char* cmd_parse(char**, int, int*);
void loop_args(char*, int*);
void open_file(char*, FILE**);
char** read_file(FILE**, int, int);
float* read_file_asfloat(FILE*, int);	/*For when "-n" is specified*/
char** selectionSort(char**, int, int);
float* qsort_floats(float*, int);
int float_comp(const void*, const void*);

int stringCompare (const void *a, const void *b );

int main(int argc, char** argv){
	if (argc < 2){
		printf("No file supplied\n");
		return 1;
	}
	int modes[3];	/*boolean array for the different modes present (-n -r -u, respectively)*/
	short i;
	for (i = 0; i < 3; i++){
		modes[i] = 0;
	}
	char* filename = cmd_parse(argv, argc, modes);
	
	FILE* infile;
	open_file(filename, &infile);
	int stringsize;
	int size = get_linecount(infile, &stringsize); /*number of lines*/
	/*Reopen file*/
	open_file(filename, &infile);

	if (modes[0] == 1){
		float* array = read_file_asfloat(infile, size);
		array = qsort_floats(array, size);
		if (modes[1] == 1 && modes[2] != 1){
			for (i = size-1; i >= 0; i--){
				printf("%g\n", array[i]);
			}
		} else if (modes[1] == 1 && modes[2] == 1){
			float last = array[size-1];
			printf("%g\n", array[size-1]);
			for (i = size-2; i >= 0; i--){
				if (array[i] != last){
					printf("%g\n", array[i]);
				}
				last = array[i];
			}
		} else if (modes[1] != 1 && modes[2] == 1){
			float last = array[0];
			printf("%g\n", array[0]);
			for (i = 0; i < size; i++){
				if (array[i] != last){
					printf("%g\n", array[i]);
				}
				last = array[i];
			}
		} else {
			for (i = 0; i < size; i++){
				printf("%g\n", array[i]);
			}
		}

		free(array);
	}
	else {
		char** buffers = read_file(&infile, size, stringsize + 1);
		buffers = selectionSort(buffers, stringsize, size);
		if (modes[1] == 1 && modes[2] != 1){
			for (i = size-1; i >= 0; i--){
				printf("%s", buffers[i]);
			}
		} else if (modes[1] == 1 && modes[2] == 1){
			char* last = buffers[size-1];
			printf("%s", buffers[size-1]);
			for (i = size-1; i >= 0; i--){
				if (strcmp(buffers[i], last) != 0){
					printf("%s", buffers[i]);
				}
				last = buffers[i];
			}
		} else if (modes[1] != 1 && modes[2] == 1){
			char* last = buffers[0];
			printf("%s", buffers[0]);
			for (i = 0; i < size; i++){
				if (strcmp(buffers[i], last) != 0){
					printf("%s", buffers[i]);
				}
				last = buffers[i];
			}
		} else{
			for (i = 0; i < size; i++){
				printf("%s", buffers[i]);
			}
		}
		for (i = 0; i < size; i++){
			free(buffers[i]);
		}
		free(buffers);
	}

	fclose(infile);
	return 0;
}
/*--------------------------------------------------------------*/
int get_linecount(FILE* infile, int* longest_string){
	/* Input: <infile>: already opened file ptr; <long...string>: int to track length of longest string;
	 * Output: returns line count, closes file, and sets longest string
	 */
	char byte;
	int nlc = 0;
	*longest_string = 0;
	int curlen = 0;

	byte = fgetc(infile);
	while (byte != EOF){
		curlen++;
		if (byte == '\n'){
			nlc++;
			if (curlen > *longest_string){
				*longest_string = curlen;
			}
			curlen = 0;
		}
		byte = fgetc(infile);
	}
	fclose(infile);
	return nlc;
}
/*--------------------------------------------------------------*/
char* cmd_parse(char** args, int argc, int* parsed){
	/* Input: <args>: the command line arguments to parse; <argc>: the number of arguments supplied; <parsed>: a 
	 * 		boolean array to set how the file will be sorted and processed
	 * Output: returns the name of the file to open and sets the parsed array accordingly
	 */
	short i = 0;
	char* filename; /*returns this at end when filename is found*/
	for (i = 1; i < argc; i++){
		if (args[i][0] == '-'){
			/*parse provided arguments, in a separate function*/
			loop_args(args[i], parsed);
		} else {	/*assumes filename has been found, this will cause problems if multiple files are provided*/
			filename = args[i];
		}
	}
	return filename;
}
/*--------------------------------------------------------------*/
void loop_args(char* arg, int* parsed /*n,r,u*/){
	/* Input: <arg>: the argument to parse through (can be "-<char>" or "-<chars>"); 
	 *        <parsed>: boolean array to set how file will be sorted and processed
	 * Output: sets the specific boolean value based on commandline options,
	 *         or terminates with a message if option is invalid
	 */
	short size = strlen(arg);
	short j;
	char pos;
	for (j = 1; j < size; j++){
		pos = arg[j];
		if (pos == 'n'){
			parsed[0] = 1;
		} else if (pos == 'r'){
			parsed[1] = 1;
		} else if (pos == 'u'){
			parsed[2] = 1;
		} else {
			printf("invalid option %s\nValid options are -nru\n", arg);
		}
	}
}
/*--------------------------------------------------------------*/
void open_file(char* filename, FILE** infile){
	/* Input: <filename>: name of the file to open; <infile>: file pointer to fopen() and test
	 * Output: opens <infile> and tests if the open was successful
	 */
	*infile = fopen(filename, "r");
	if (!(*infile)){
		printf("file: %s could not be opened\n", filename);
		exit(1);
	}
}
/*--------------------------------------------------------------*/
char** read_file(FILE** infile, int size, int strsize){
	/* Input: <infile>: file to read 
	 * Output: reads all lines into an array of strings, and returns it
	 */
	char** array;
	short i;
	array = (char**)malloc(sizeof(char*) * size);
	for (i = 0; i < size; i++){
		array[i] = (char*)malloc(strsize + 1); /*+1 for null termination character*/
	}
	i = 0;
	while (fgets(array[i], strsize, *infile)){
		i++;
	}
	return array;
}
/*--------------------------------------------------------------*/
float* read_file_asfloat(FILE *infile, int size){
	/* Input: <infile>: file pointer to read from; <size>: number of elements in the buffer
	 * Output: returns array of floats read from file
	 */
	float* array = (float*)malloc(sizeof(int) * size);
	short i = 0;
	while (fscanf(infile, "%f", &array[i]) != EOF){
		i++;
	}
}
/*--------------------------------------------------------------*/
/*--------------------------------------------------------------*/
/*-----Sorting Funcs--------------------------------------------*/
char** selectionSort(char **arr, int strlength, int n) 
	/* Desc: string sorting algorithm found and modified from online
	 * Input: <arr>: the array to sort; <strlengt>: max length of strings in the array; <n>: number of strings
	 * Output: returns the sorted array
	 */
{ 
    int i, j, min_idx; 
   
    char minStr[strlength]; 
    for (i = 0; i < n-1; i++) 
    { 
        int min_idx = i; 
        strcpy(minStr, arr[i]); 
        for (j = i+1; j < n; j++) 
        { 
            if (strcmp(minStr, arr[j]) > 0) 
            { 
                strcpy(minStr, arr[j]); 
                min_idx = j; 
            } 
        } 
   
        if (min_idx != i) 
        { 
            char temp[strlength]; 
            strcpy(temp, arr[i]); //swap item[pos] and item[i] 
            strcpy(arr[i], arr[min_idx]); 
            strcpy(arr[min_idx], temp); 
        } 
    } 
	return arr;
} 
/*--------------------------------------------------------------*/
float* qsort_floats(float* array, int size){
	qsort(array, (size_t)size, sizeof(float), &float_comp);
	return array;
}
/*--------------------------------------------------------------*/
int float_comp(const void* a, const void* b){
	if (*(float*)a > *(float*)b){
		return 1;
	} else if (*(float*)a < *(float*)b){
		return -1;
	} else if (*(float*)a == *(float*)b){
		return 0;
	}
}