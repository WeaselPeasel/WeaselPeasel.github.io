/*
 * Cwc.c
 * Programmer: Caleb B
 * Description: gets the line, word, and byte count of a file (printed in that order)
 * Input: the name of a file
 * Output: prints the line, word, and byte (character) count of the file, if it exists
 * NOTE: word count is a bit off. Ends up lower or higher in different circumstances
 */
#include <stdio.h>
#include <stdlib.h>

void openFile(FILE**, char*);
void process(int*, int*, int*, FILE**);

int main(int argc, char** argv){
	if (argc < 2){
		printf("No argument supplied...\n");
		return 1;
	}
	char* filename = argv[1];
	FILE* infile;
	openFile(&infile, filename);

	int byte_count = 0;
	int word_count = 0;
	int line_count = 0;
	/*Process the file*/
	process(&byte_count, &word_count, &line_count, &infile);

	/*Print the results*/
	printf("%d %d %d %s\n", line_count, word_count, byte_count, filename);
}
/*------------------------------------------------------------*/
void openFile(FILE** infile, char* filename){
	/* Input: <infile>: address of original file pointer; <filename> the name of the file
	 * Output: opens <infile> and checks if it was successful
	 */
	*infile = fopen(filename, "r");
	if (!(*infile)){
		printf("File %s could not be opened...\n", filename);
		exit(1);
	}
}
/*------------------------------------------------------------*/
void process(int* bc, int* wc, int* lc, FILE** infile){
	char current;
	int spacefound = 1; /*use to identify white-space separated strings; set at 
						1 to identify the first word in the file*/
	current = fgetc(*infile);
	while (current != EOF){
		*bc += 1;
		if (current == '\n'){
			if (spacefound == 0){
				spacefound = 1;
			}
			*lc += 1;
		} else if (current == ' '){
			if (spacefound == 0){
				spacefound = 1;
			}
		} else {
			if (spacefound == 1){
				*wc += 1;
				spacefound = 0;
			} 
		}
		current = fgetc(*infile);
	}
}