/*
 * Ccp.c
 * Programmer: Caleb B
 * Description: copies contents of <file1> into <file2>
 * Input: ./Ccp <file1> <file2> where <file1> is a file with any number of lines of any length, 
 * 		and <file2> is an empty file or a file that may be overwritten with <file1>'s contents
 * Output: <file2> contains <file1>'s contents
 */
#include <stdio.h>
#include <stdlib.h>
void openInput(FILE**, char*);
void openOutput(FILE**, char*);
void double_size(char**, int*);

int main(int argc, char** argv){
	if (argc < 3){
		printf("Not enough arguments supplied\n");
		return 1;
	}

	int size = 200;
	int index = 0;
	char* buffer;
	FILE* infile;
	FILE* outfile;
	buffer = (char*)malloc(size);

	openInput(&infile, argv[1]);
	openOutput(&outfile, argv[2]);

	char readin;
	readin = fgetc(infile);
	while (readin!=EOF){
		buffer[index] = readin;
		index++;
		if (index == size){
			double_size(&buffer, &size);
		}
		readin = fgetc(infile);
	}
	fprintf(outfile, "%s", buffer);
	return 0;
}

void openInput(FILE** input, char* filename){
	/* Input: <input> = file pointer to open
	 * Ouput: opens file with name <filename> and checks the success of fopen()
	*/
	*input = fopen(filename, "r");
	if (!(*input)){
		printf("file: %s could not be opened\n", filename);
		exit(1);
	}
}

void openOutput(FILE** output, char* filename){
	/* Input: <output> = file pointer to open
	 * Ouput: opens file with name <filename> and checks the success of fopen()
	*/
	*output = fopen(filename, "w");
	if (!(*output)){
		printf("file: %s could not be opened\n", filename);
		exit(1);
	}
}

void double_size(char** buffer, int* size){
	/* Input: <buffer> is the buffer to resize; <size> is the current size of the file
	 * Ouput: <size> is doubled and <buffer> is twice as big
	*/
	char* tmp = *buffer;
	*buffer = (char*)malloc(*size * 2);
	short i;
	for (i = 0; i < *size; i++){
		*buffer[i] = tmp[i];
	}
	free(tmp);
	*size = *size * 2;
}