/*
 * Cavergae.c
 * Programmer: Caleb B
 * Description: Reads integers from a file, and finds their average
 * Input: the name of a file with a list of integers, one on each line, with no other data
 * Output: prints the average of all the integers to the screen, up to 4 decimal places
 */

#include <stdio.h>

int main(int argc, char** argv){
	if (argc < 2){
		printf("missing filename\n");
		return 1;
	}
	/* Open File for reading */
	FILE* input;
	input = fopen(argv[1], "r");
	if (!input){
		printf("file %s could not be opened!\n", argv[1]);
		return 1;
	}
	/* Declare variables */
	int count = 0;
	int sum = 0;
	int read_in;
	float average;
	/* Read File */
	while (fscanf(input, "%d", &read_in)!=EOF){
		sum += read_in;
		count++;
		printf("%d\n", read_in);
	}
	if (count == 0){
		printf("file was empty\n");
		return 0;
	}
	average = ((float)sum) / ((float)count);
	printf("%.4f\n", average);
	
	return 0;
}
