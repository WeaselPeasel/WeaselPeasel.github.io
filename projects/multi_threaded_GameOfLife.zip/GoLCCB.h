#ifndef _GOL_H
#define _GOL_H
#include <stdlib.h>
#include <stdio.h>
/*
 * GoLCCB.h
 * Programmer: CCB, Timmy
 */
// Function Declarations
void errorCheck(/*in*/char* process);																// Prints error message and exits program
char** setUp(/*in*/int numArgs, char** args, /*in-out*/int* cols, int* rows, int* iterator);		// Initiates the setUp of the grid
char** readFile(/*in-out*/int** cols, int** rows, /*in*/char* fileName, /*in-out*/int** iterator);	// Reads file for rows, columns, and live spaces
char** initGrid(/*in*/int col, int row);															// Initiates all values in grid to dead
//----------------------------------------------------------------
#endif
