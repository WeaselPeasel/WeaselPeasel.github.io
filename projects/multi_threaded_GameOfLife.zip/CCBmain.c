#include "GoLCCB.h"
#include "GameLogic.h"
//#include "timeStruct.h"
/*
 * CCBmain.c
 * Driver main for GoL Project
 * Programmers: Caleb Braddick, Timmy McCormack
 * 
 * Summary: Runs Conway's Game of Life. Has options for wrapping, display, and display speed, provided by command line arguments
 */

//-----------------------------------------------------------------------------
// Extra Functions
int checkParams(char** argv, int argc);
void* threadFunc(void* arg);
float returnTime(struct timeval start, struct timeval end);

// args = {./GOL, infile, # of threads, col/row partitioning, wrap, show, speed}
int main(int argc, char** args)
{
	// Set some variables
	int numThread = atoi(args[2]);
	char* partitionMode = args[3];
	long i;

	int numMore;
	int baseCase;

	// Initialize the locks and barrier
	pthread_mutex_init(&lock, NULL);
	pthread_mutex_init(&trylocker, NULL);
	pthread_barrier_init(&barrier, NULL, numThread);

	// Check number of args
	checkParams(args, argc);

	int Columns, Rows, Iterations, speed;
	if (strcmp(args[5], "show") == 0){
		if (strcmp(args[6], "fast") == 0){
			speed = 1000000/30;
		} else if (strcmp(args[6], "med") == 0){
			speed = 1000000/10;
		} else if (strcmp(args[6], "slow") == 0){
			speed = 1000000/3;
		}
		else{
			errorCheck(args[0]);
		}
	}

	// Initialize the grid
	oldBoard = setUp(argc, args, &Columns, &Rows, &Iterations);
	if (strcmp(args[5], "show") == 0){
		printGrid(Rows, Columns);
	}
	// Initialize newBoard
	newBoard = malloc(sizeof(char*) * Rows); 
	for (i = 0; i < Rows; i++){
		newBoard[i] = malloc(sizeof(char) * Columns);
	}

	// Set up timer--
	struct timeval start;
	struct timeval end;
	gettimeofday(&start, NULL);

	// Launch Threads
	gridStorer* Arg = malloc( sizeof(gridStorer) * numThread);
	
	int counter = 0;
	pthread_t* tid = (pthread_t*)malloc( sizeof(pthread_t) * numThread );

	int boolean;
	for (i = 0; i < numThread; i++){
		Arg[i].mainArgs = args;
		Arg[i].iterations = Iterations;
		Arg[i].speed = speed;
		Arg[i].totalCol = Columns;
		Arg[i].totalRow = Rows;

		if (strcmp(partitionMode, "col") == 0){
			baseCase = Rows / numThread;
			numMore = Rows % numThread;
			boolean = 0;
			Arg[i].mincols = 0;
			Arg[i].maxcols = Columns;
		} else if (strcmp(partitionMode, "row") == 0){
			baseCase = Columns / numThread;
			numMore = Columns % numThread;
			boolean = 1;
			Arg[i].minrows = 0;
			Arg[i].maxrows = Rows;
		} else {
			errorCheck(args[0]);
		}
		if (boolean == 1){
			Arg[i].mincols = counter;
			if (i < numMore){
				counter += (baseCase + 1);
				Arg[i].maxcols = counter;
			} else {
				counter += baseCase;
				Arg[i].maxcols = counter;
			}
		} else {
			Arg[i].minrows = counter;
			if (i < numMore){
				counter += (baseCase + 1);
				Arg[i].maxrows = counter;
			} else {
				counter += baseCase;
				Arg[i].maxrows = counter;
			}
		}
		Arg[i].id = i;
		pthread_create(&(tid[i]), NULL, threadFunc, &(Arg[i]));
	}

	for (i = 0; i < numThread; i++){
		pthread_join(tid[i], NULL);
	}
	// Now, run the program	
	gettimeofday(&end, NULL);
	if (strcmp(args[5], "hide") == 0){
		printGrid(Rows, Columns);
	}

	// Calculate time taken by the program
	float result = returnTime(start, end);
	printf("\nProgram took %f seconds to run through %i iterations.\n", result, Iterations);
	printf("\nTotal number of live cells processed: %d\n", endLive);

	// Cleanup memory
	for (i = 0; i < Rows; i++){
		free(oldBoard[i]);
	}
	free(oldBoard);
	for (i = 0; i < Rows; i++){
		free(newBoard[i]);
	}
	free(newBoard);
	free(Arg);
	pthread_mutex_destroy(&lock);
	pthread_mutex_destroy(&trylocker);
	pthread_barrier_destroy(&barrier);
	return 0;	
}

// args = {./GOL, infile, # of threads, col/row partitioning, wrap, show, speed}
// Check args
int checkParams(char** argv, int argc)
{
	if(argc < 6){
		errorCheck(argv[0]);
	} else if (argc < 7 && strcmp(argv[5], "show") == 0){
		errorCheck(argv[0]);
	} if (strcmp(argv[4], "wrap") != 0 && strcmp(argv[4], "nowrap") != 0){
		errorCheck(argv[0]);
	} if (strcmp(argv[5], "show") != 0 && strcmp(argv[5], "hide") != 0){
		errorCheck(argv[0]);
	} if (argc == 7 && strcmp(argv[5], "show") != 0){
		errorCheck(argv[0]);
	}
	return 0;
}

// Function for threads
void* threadFunc(void* arg){
	gridStorer* var = arg;
	Run((*var).mincols, (*var).maxcols, (*var).minrows, (*var).maxrows, (*var).mainArgs, (*var).iterations, (*var).speed, (*var).totalRow, (*var).totalCol);

	printf("tid: %d: rows: %d:%d (%d): cols: %d:%d (%d)\n", (*var).id, (*var).minrows, (*var).maxrows, (*var).maxrows - (*var).minrows + 1, (*var).mincols, (*var).maxcols, (*var).maxcols - (*var).mincols + 1);
	fflush(stdout);
	return NULL;
}

// Simple function to get time of program
float returnTime(struct timeval start, struct timeval end)
{
	float totaltime = end.tv_sec - start.tv_sec + (end.tv_usec - start.tv_usec)/1000000;
	return totaltime;
}
