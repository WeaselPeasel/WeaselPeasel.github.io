#ifndef _GAM_LOG
#define _GAM_LOG
#include "GoLCCB.h"
#include "timeStruct.h"
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
/*
 * GameLogic.h
 * Programmer: Caleb Braddick, Timmy McCormack
 */

//Function Declarations
void iterateStep(/*in*/int startrows, int endrows, int startcols, int endcols, char** args, int totRow, int totCol);	// Function for moving from one iteration to the next, and changing the grid accordingly

int checkNeighbors(/*in*/int x, int y, int cols, int rows, char** args);					// Returns 0 if cell remains stagnant, -1 if cell dies, 1 if cell turns live
//----------------------------------------------------------------------
void Run(/*in*/int startcols, int endcols, int startrows, int endrows, char** args, int iterations, int speed, int totRow, int totCol);				// Runs program loop
void printGrid(/*in*/int rows, int cols);													// Prints the grid out to the screen


#endif
