#ifndef TIMESTRUCT
#define TIMESTRUCT
#include <sys/time.h>
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
/*
 * Declares helper method for calculating time
 * and a struct to pass grid information to each thread
 */
// Declare important global variables
pthread_mutex_t lock;
pthread_mutex_t trylocker;
pthread_barrier_t barrier;

char** oldBoard;
char** newBoard;
int roundLive;	// Live cells processed per round
int endLive;	// Live cells processed whole game

// Declare struct to pass grid information to threads
struct gridStorer{
	int mincols, maxcols;
	int minrows, maxrows;
	int id, speed, iterations;
	char** mainArgs;
	int totalRow, totalCol;
};
typedef struct gridStorer gridStorer;
#endif