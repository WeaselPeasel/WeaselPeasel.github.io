#include "GameLogic.h"
#include "timeStruct.h"
/*
 * GameLogic.c
 * Implementation file for GameLogic.h
 * Programmer: Caleb Braddick, Timmy McCormack
 * Summary: As name implies, handles game logic (converting cells from live to dead and vice versa, as needed. Parses remaining command line args [show/hide, wrap, speed])
 */
// Function Definitions
void iterateStep(int startrows, int endrows, int startcols, int endcols, char** args, int totRow, int totCol)
{
	int x, y, result;
	int localLive = 0;
	for (x = startrows; x < endrows; x++){
		for (y = startcols; y < endcols; y++){
			result = checkNeighbors(x, y, totCol, totRow, args);
			if(result == -1){
				newBoard[x][y] = '*';
			} else if(result == 1){
				newBoard[x][y] = '@';
				localLive++;
			} else{
				newBoard[x][y] = oldBoard[x][y];
			}
		}
	}

	// Create deep copy (copy each individual element of blankSlate into grid, to prevent mismanaging memory)
	pthread_barrier_wait(&barrier);
	for (x = startrows; x < endrows; x++){
		for (y = startcols; y < endcols; y++){
			oldBoard[x][y] = newBoard[x][y];
		}
	}
	// Reset the new board to be blank
	pthread_barrier_wait(&barrier);
	if (pthread_mutex_trylock(&trylocker) == 0){
		int i;
		for (i = 0; i < totRow; i++){
			free(newBoard[i]);
		}
		free(newBoard);
		newBoard = malloc(sizeof(char*) * totRow); 
		for (i = 0; i < totRow; i++){
			newBoard[i] = malloc(sizeof(char) * totCol);
		}
		pthread_mutex_unlock(&trylocker);
	}
	pthread_barrier_wait(&barrier);
	// Update live cell counters
	pthread_mutex_lock(&lock);
	roundLive += localLive;
	endLive += localLive;
	pthread_mutex_unlock(&lock);
}
//--------------------------------------------------------------------
int checkNeighbors(int x, int y, int cols, int rows, char** args)
{
	// Declare variables
	int i;
	int xPlus = x + 1;
	int xMinus = x - 1;
	int yPlus = y + 1;
	int yMinus = y - 1;
	int count = 0;			// track how many live cells are found
	
	int neighbors[8][2] = {{xMinus, yMinus}, {x, yMinus}, {xPlus, yMinus}, {xPlus, y}, {xPlus, yPlus}, {x, yPlus}, {xMinus, yPlus}, {xMinus, y}};
	// Remove coordinates from array if nowrap is selected and points are off array
	for (i = 0; i < 8; i++){
		if ( ( neighbors[i][0] < 0 || neighbors[i][0] >= rows || neighbors[i][1] < 0 || neighbors[i][1] >= cols ) ){
			if (strcmp(args[4], "wrap") != 0){
				neighbors[i][0] = -3;
				neighbors[i][1] = -3;
			}
		}
	}
	// Begin parsing through neighbors. Start in bottom left and work around clockwise. Count number of live neighbors
	for (i = 0; i < 8; i++){
		if (neighbors[i][0] == -1){
			neighbors[i][0] += rows;
		}
		if (neighbors[i][1] == -1){
			neighbors[i][1] += cols;
		}
		if (neighbors[i][0] >= rows){
			neighbors[i][0] -= rows;
		}
		if (neighbors[i][1] >= cols){
			neighbors[i][1] -= cols;
		}
		if (neighbors[i][0] != -3){
			if (oldBoard[neighbors[i][0]][neighbors[i][1]] == '@'){
				count++;
			}
		}
	}
	// Parsing finished. Now return
	if (oldBoard[x][y] == '@'){
		if (count <= 1 || count >= 4){
			return -1;
		}
	} else if (oldBoard[x][y] == '*'){
		if (count == 3){
			return 1;
		}
	}
	return 0;
}
//--------------------------------------------------------------
void Run(int startcols, int endcols, int startrows, int endrows, char** args, int iterations, int speed, int totRow, int totCol){
	int i;
	for (i = 0; i < iterations; i++){
		iterateStep(startrows, endrows, startcols, endcols, args, totRow, totCol);
		pthread_barrier_wait(&barrier);

		if (strcmp(args[5], "show") == 0){
			if (pthread_mutex_trylock(&trylocker) == 0){
				printGrid(totRow, totCol); 
				printf("\nNumber of live cells processed: %d\n", roundLive);
				roundLive = 0;
				usleep(speed);
				pthread_mutex_unlock(&trylocker);
			}
		}
		pthread_barrier_wait(&barrier);
	}
}
//---------------------------------------------------------------
void printGrid(int rows, int cols) // displays the grid to the screen
{
	system("clear"); 						// Clear Screen
	int i, j;
	printf("\n");
	for (i = 0; i < rows; i++){
		for (j = 0; j < cols; j++){
			printf("%c ", oldBoard[i][j]);
		}
		printf("\n");
	}
}
//-----------------------------------------------------------------
