#include "GoLCCB.h"
/*
 * GoLCCB.c
 * Implementation file for GoLCCB.h
 * Programmer: Caleb Braddick, Timmy McCormack
 */
// Function Definitions
void errorCheck(char* process)
// Gets called when error is encountered and program needs to exit
{
		printf("Process %s terminating with exit code 1\n", process);
		printf("Usage:\n\t./GoL.exe <filename> <num threads> <col/row part> <wrap/nowrap> <show/hide> <(ONLY IF 'show')slow/med/fast>\n");
		printf("\tfilename: file to read\n\twrap: used to have live enitities either wrap to other end when edge is hit or not.\n");
		printf("\tnum threads: the number of threads to start for the given game.\n\tcol/row: determine whether to use partitioning via rows or via columns\n");
		printf("\tshow: Used to display step-by-step process of the game running. (NOTE: if 'show' is used, program slows significantly)\n");
		printf("\tslow: Is not read if 'hide' is chosen. Selects animation speed for game.\n");
		exit(1);
}
//----------------------------------------------------------------
char** setUp(int numArgs, char** args, int* cols, int* rows, int *iterator)
{
	// Declare Variables
	int i;
	char **grid;
	// Read file
	grid = readFile(&cols, &rows, args[1], &iterator);
	return grid;
}
//----------------------------------------------------------------
char** readFile(/*in/out*/int** cols, int** rows,/*in*/ char* fileName, int** iterator)
{
	// Declare Variables
	int x, y;		// "x y coordinates" for marking grid cells as "live"
	FILE* infile;
	char **grid;
	// Get values for 
	infile = fopen(fileName, "r");
	if (infile == NULL){
		printf("errorCheck: file %s could not be opened\n", fileName);
		errorCheck("./GoL");
	}
	if(fscanf(infile, "%i", *rows) == 0){
		printf("errorCheck: number of rows could not be read\n");
		errorCheck("./GoL");
	}
	if(fscanf(infile, "%i", *cols) == 0){
		printf("errorCheck: number of coluns could not be read\n");
		errorCheck("./GoL");
	}
	if(fscanf(infile, "%i", *iterator) == 0){
		printf("errorCheck: number of iterations could not be read\n");
		errorCheck("./GoL");
	}
	grid = initGrid(**cols, **rows);
	//Read values to initiate "live" cells
	while (fscanf(infile, "%i %i", &x, &y) > 1){
		grid[x][y] = '@';
	}
	fclose(infile);
	return grid;
}
//----------------------------------------------------------------
char** initGrid(int col, int row) //initializes all values in grid to * (dead)
{
	// Declare Variables
	int i, j;
	// Allocate memory for grid
	char **pchar = malloc(sizeof(char*) * row);
	for (i = 0; i < row; i++){
		pchar[i] = malloc(sizeof(char) * col);
	}
	// Initialize grid values
	for (i = 0; i < row; i++){
		for (j = 0; j < col; j++){
			pchar[i][j] = '*';
		}
	};
	return pchar;
}
//----------------------------------------------------------------

