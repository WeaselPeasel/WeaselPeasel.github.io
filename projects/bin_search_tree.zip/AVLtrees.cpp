/* AVLtrees.cpp
 * 
 * Description: Program implements a binary tree base class and a binary search tree
 * derived class. 
 *
 * Programmer: Caleb Braddick
 */


#include "AVLtrees.h"
#include <iomanip>

/**********************binary search tree*****************************/
/**********************method definitions*****************************/

// Insert item into proper location in BST.
void binarySearchTree :: insertItem (elemType item)
{
   nodeType *p = new nodeType;
   p->data = item;
   p->left = NULL;
   p->right = NULL;
   if (this->root==NULL)
   {
      this->root = p;
      return;
   }
   nodeType *parent;
   nodeType *cur;
   cur = this->root;
   while(cur)
   {
      parent = cur;
            
      elemType currentText = (*cur).data;
            
      if (item == currentText ) {
         cout << "Item " << item << " is already in tree; insert aborted." << endl;
         return;
      }
            
      else if (item < currentText)
         cur = cur->left;
            
      else
         cur = cur->right;
        
   }
   if (item < (*parent).data)
        parent->left = p;
    else
        parent->right = p;
}


/*********************************************************************/


// Search for given key in BST.  Returns true if found, false otherwise.
bool binarySearchTree :: search (const elemType key, 
					   nodeType *p) const
{
   bool leftside, rightside;

   if (p) {
      if (p->data == key)
         return true;
      else {
	 leftside = search (key, p->left);
	 rightside = search (key, p->right);
	 return (leftside || rightside);
      }
   } else
      return false;
}


/*************************binary tree*********************************/
/**********************method definitions*****************************/


// Returns the number of nodes in binary tree.
int binaryTree :: nodecount (nodeType *p) const
{
   if (p) {
      return 1 + nodecount (p->left) + nodecount (p->right);
   } else
      return 0;
}


/*********************************************************************/


// Displays data in postorder; note that << operator must be overloaded
// if elemType is a user-defined type.
void binaryTree :: postorder (nodeType *p) const
{
   if (p) {
      postorder (p->left);
      postorder (p->right);
      cout << p->data << " ";
   }
}


/*********************************************************************/


// Displays data in inorder; note that << operator must be overloaded
// if elemType is a user-defined type.
void binaryTree :: inorder (nodeType * p) const
{
   if (p) {
      inorder (p->left);
      cout << p->data << " ";
      inorder (p->right);
   }
}


/*********************************************************************/


// Displays data in preorder; note that << operator must be overloaded
// if elemType is a user-defined type.
void binaryTree :: preorder(nodeType *p) const
{
   if (p) {
      cout << p->data << " ";
      preorder (p->left);
      preorder (p->right);
   }
}


/*********************************************************************/
// Returns integer representing the height of the tree
short binaryTree :: treeHeight()
{
	short height = 0;
	queue<nodeType*> q;
	q.push(this->root);
	q.push(NULL);
	while (!q.empty())
	{
		if (q.front() != NULL)
		{
			if ( (*q.front()).left != NULL )
				q.push( (*q.front()).left );
			if ( (*q.front()).right != NULL )
				q.push( (*q.front()).right ); 
			q.pop();
		}
		else
		{
			height++;
			q.pop();
			if (!q.empty())
				q.push(NULL);
		}
	}
	
	return height - 1;	//minus 1 to ensure we count number of edges
}
//******************************************************************/
//Returns tree height starting from any node
short binaryTree :: myHeight(nodeType *p)
{
	if (p == 0)
        return 0;
    else
    {
        return 1 + (max( this->myHeight( p->left ),this->myHeight( p->right ) ) ) ;
    }
}

//******************************************************************/
//Prints out tree in an orderly fashion
void binaryTree :: treeDisplay()
{
   queue<nodeType*> q;
   nodeType *null;
   null = new nodeType;
   null->data = ' ';
   q.push(this->root);
   q.push(NULL);
   short lv1 = 1;
   short lv2 = 2;	//store max number of nodes per level
   short lv3 = 4;
   short TAB = 20;	//number of spaces
   short spaces = 8;
   short count = 0;
   for (short i = 0; i < 3; i++)
   {
	count = 0;
      	while (q.front() != NULL)
      	{
         	if ( (*q.front()).left != NULL )
            		q.push( (*q.front()).left );
           	else
	   	 	q.push( null );
         	if ( (*q.front()).right != NULL )
            		q.push( (*q.front()).right );
		else
			q.push( null );
		if (count > 0)
		{
			cout << setw(spaces) << " " << q.front()->data;
		}
		else
			cout << setw(TAB) << " " << q.front()->data;
        	q.pop();
		count++;
      	}
      	cout << endl;
	TAB -= 4;
	spaces -= 2;
      	q.pop();
      	if (!q.empty())
        	q.push(NULL);
   }

	
}

/**************************************************/

/*void binaryTree :: myPrinter(nodeType *p, short xval, short level)
{
	if (p == this->root)
		cout << setw(xval) << " " << p->data;
	else
	{
		
	}
} */

void balancedBST :: balanceFactors()
{
	getBalance(root);
	cout << endl;
}
//************************************************/
void balancedBST :: getBalance(nodeType* p)
{
	short balFac = 0;
	if (p)
	{
		balFac = ( myHeight(p->left) - myHeight(p->right) );
		cout << p->data << " : " << balFac << "   ";
		getBalance (p->left);
		getBalance (p->right);
	}
}


