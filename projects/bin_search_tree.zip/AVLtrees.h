/* AVLtrees.h
 * 
 * Program defines a binary tree base class and a binary search tree
 * derived class.  The main() tests out the various class methods.
 *
 */

#include<iostream>
#include<assert.h>
#include<queue>

using namespace std;

typedef char elemType;		// "placeholder" for data type

// binary tree class
class binaryTree {
protected:
   // binary tree node
   struct nodeType {
      elemType data;		// store data
      nodeType * left;		// link to left subtree
      nodeType * right;		// link to right subtree
      short balFac;     // stores the level at which this node is located
   };
   nodeType * root;  
private:
   void inorder (nodeType *) const;
   void preorder (nodeType *) const;
   void postorder (nodeType *) const;
   int nodecount (nodeType *) const;

   void myPrinter(nodeType* p, short xval);
public: 
   // constructor
   binaryTree () {root = NULL;};

   // some tree information methods
   int treeNodeCount () const {return nodecount (root);};
        
   // tree traversals
   void postorderTraversal () const {postorder (root);};
   void inorderTraversal () const {inorder (root);};
   void preorderTraversal () const {preorder (root);};

   // student added methods
   short treeHeight();
   short myHeight(nodeType *p);
   void treeDisplay();
};


// binary search tree class
class binarySearchTree : public binaryTree {
private:
   bool search (const elemType, nodeType *) const;
public:
   bool searchItem (const elemType key) {return search (key, root);};
   void insertItem (const elemType);
};


// balanced search tree class
class balancedBST : public binarySearchTree {
public:
   void balanceFactors();
   void getBalance(nodeType* p);
};
