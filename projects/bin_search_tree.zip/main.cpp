/* mainWEB.cpp
 * 
 * Sample main() for A5
 *
 */

#include "AVLtrees.h"

// Silly little main() that lets user type in characters, and store
// them in a binary search tree.
// Tests out various binary (search) tree functions.
int main () {
   balancedBST mytree;
   char newch;

   cout << "Enter char: ";
   cin.get (newch);
   cin.get ();
   while (newch != '0') {
      mytree.insertItem (newch);
      cout << "Enter char: ";
      cin.get (newch);
      cin.get ();
   }

   cout << endl;
   cout << "Inorder traversal: ";
   mytree.inorderTraversal ();
   cout << endl << "Preorder traversal: ";
   mytree.preorderTraversal ();
   cout << endl << "Postorder traversal: ";
   mytree.postorderTraversal ();
   cout << endl << endl;

   
   cout << "Tree height     : " << mytree.treeHeight() << endl;
   
   cout << "Display: " << endl;
   mytree.treeDisplay ();
   cout << endl;

   mytree.balanceFactors();
   

   cout << "Enter search key: ";
   cin.get (newch);
   if (mytree.searchItem (newch))
      cout << newch << " found in tree" << endl;
   else
      cout << newch << " not found in tree" << endl;

   return 0;
}
