//#include "global.h"
#include "producer.h"
#include "consumer.h"
#include <string.h>
/*
 * main.c
 * Programmer: Caleb Braddick, et al.
 * Summary: Main driver for Password Cracker
 */

void usage();

// Argv = {program_name, dictionary_file, password_file, output_file, #consumer_threads}
int main(int argc, char** argv)
{
	long i;
	if (argc < 5){
		printf("Not enough arguments supplied\nTerminating...\n");
		usage();
	}
	// Initialize aspects of theBuffer
	pthread_mutex_init(&theBuffer.m, NULL);
	pthread_mutex_init(&theBuffer.fin, NULL);
	pthread_cond_init(&theBuffer.more, NULL);
	pthread_cond_init(&theBuffer.less, NULL);
	theBuffer.nextin = 0;
	theBuffer.nextout = 0;
	theBuffer.occupied = 0;
	theBuffer.pdone = 0;
	theBuffer.passfound = 0;
	theBuffer.buffer = malloc( sizeof(char*) * SIZE );
	for (i = 0; i < SIZE; i++){
		theBuffer.buffer[i] = malloc( sizeof(char*) * 50 );
	}
	// Check numThreads
	int numThread = atoi(argv[4]);
	if (numThread == 0){
		printf("Cannot launch 0 threads!!\nTerminating...");
		usage();
	}
	// Begin launching threads
	pthread_t* Thread = malloc(sizeof(pthread_t) * numThread + 1);
	Producer p;
	// Initialize Consumer struct
	Consumer c;
	c.outputFile = argv[3];
	
	FILE* passWord = fopen(argv[2], "r");
	if (passWord == NULL){
		printf("File %s could not be opened\nTerminating...\n", argv[2]);
		exit(-1);
	}
	// Read File
	char HASH[65];
	fscanf(passWord, "%s", HASH);
	c.HASH = HASH;

	// Launch threads
	for (i = 0; i < numThread+1; i++){
		if (i == 0){
			// Launch 1 producer
			p.dict = argv[1];
			pthread_create(&Thread[i], NULL, produce, (void*)&p);
		} else{
			// Launch consumer
			pthread_create(&Thread[i], NULL, Run, (void*)&c);
		}
	}

	// Now join
	for (i = 0; i < numThread + 1; i++){
		pthread_join(Thread[i], NULL);
	}

	// Cleanup
	for (i = 0; i < SIZE; i++){
		free(theBuffer.buffer[i]);
	}
	free(theBuffer.buffer);
	pthread_mutex_destroy(&theBuffer.m);
	pthread_cond_destroy(&theBuffer.more);
	pthread_cond_destroy(&theBuffer.less);

	return 0;
}

void usage()
/*
 * prints out a help menu for the program
 */
{
	printf("Usage:\n");
	printf("  ./program_name <dict> <password> <output> <#_of_threads>\n");
	printf("\tdict:\tFile containing dictionary you wish to parse through to find password.\n");
	printf("\tpassword:\tFile containing hashed version of password.\n");
	printf("\toutput:\tFile name to write unhashed password to.\n");
	printf("\t#_of_threads:\tNumber of consumer threads to launch. Must be more than 0.\n");
	exit(1);
}