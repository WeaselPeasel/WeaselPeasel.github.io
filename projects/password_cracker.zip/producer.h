#ifndef _PRODUCER_
#define _PRODUCER_
#include "global.h"
#include <string.h>
/*
 * producer.h
 * Programmer: Caleb Braddick, et al.
 * Summary: declares functions that need to be used by producer thread in program
 */
// Declare functions
struct Producer{
	char* dict;		//Filename string
};
typedef struct Producer Producer;

void* produce(void* arg);
void writeToBuffer(char** item, int size);

#endif