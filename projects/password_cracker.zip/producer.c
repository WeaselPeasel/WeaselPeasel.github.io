#include "producer.h"
/*
 * producer.c
 * Programmer: Caleb Braddick, et al.
 * Summery: Definitions for functions that producer thread will use
 */

void* produce(void* args)
// Function run by producer thread. Reads words from dictionary file and adds them to the buffer
{
	int size = 0;
	int i;
	int ret = 0;
	Producer* var = args;
	FILE* dictionary = fopen( (*var).dict, "r");
	if (dictionary == NULL){
		printf("File %s cannot be opened...\nTerminating...\n", (*var).dict);
		exit(1);
	}
	// Set item
	char** item = malloc( sizeof(char*) * 100 );
	for (i = 0; i < 100; i++){
		item[i] = malloc( sizeof(char) * 50 );
	}
	
	while(ret != EOF){
		i = 0;
		while(ret != EOF && i < 100){
			ret = fscanf(dictionary, "%s", item[i]);
			i++;
			size++;
			//printf("Producer loop hit\n");
		}
		writeToBuffer(item, size);
		size = 0;
	}
	// finish and cleanup
	pthread_mutex_lock(&theBuffer.fin);
	theBuffer.pdone = 1;
	pthread_mutex_unlock(&theBuffer.fin);
	for (i = 0; i < 100; i++){
		free(item[i]);
	}
	free(item);
	printf("Producer has finished reading from buffer\n");
	pthread_cond_broadcast(&theBuffer.more);
	return NULL;
}
//----------------------------------------
void writeToBuffer(char** item, int size)
// Function called to add item to the buffer, with all the necessary signals and locks included
{
	int i;
	pthread_mutex_lock(&theBuffer.m);
	// Wait on condition Variable
	while (theBuffer.occupied >= (SIZE - 100)){
		pthread_cond_wait(&theBuffer.less, &theBuffer.m);
	} if (theBuffer.occupied >= (SIZE - 100)){
		printf("CRITICAL ERROR\n");
		exit(-1);
	}
	// Add items to the buffer
	i = 0;
	while (i < size){
		strcpy(theBuffer.buffer[theBuffer.nextin], item[i]);
		theBuffer.nextin++;
		if (theBuffer.nextin == SIZE){
			theBuffer.nextin = 0;
		}
		theBuffer.occupied++;
		i++;
	}
	// Signal and unlock
	pthread_cond_signal(&theBuffer.more);
	pthread_mutex_unlock(&theBuffer.m);
}