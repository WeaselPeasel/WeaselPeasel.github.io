#!/bin/bash
# compile main program
gcc sha-256.c consumer.c producer.c main.c -g -o bigBoi -lpthread

# compile password writing program
gcc sha-256.c HASHWRITER.c -o HASHWRITER