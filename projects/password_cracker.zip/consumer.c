#include "consumer.h"
/*
 * consumer.c
 * Programmer: Caleb Braddick, et al.
 * Summary: defines functions to be called by consumer threads
 */


void* Run(void* arg)
// Main function run by consumer thread.
{
	Consumer* var = arg;
	int returnval;
	char* item;
	// Begin
	while (!theBuffer.passfound && !(theBuffer.occupied <= 0 && theBuffer.pdone)){
		item = getWord();
		
		if (item != NULL){
			//printf("item = %s\n", item);
			if (!theBuffer.passfound && !(theBuffer.occupied <= 0 && theBuffer.pdone)){
				returnval = consume(&item, (*var).HASH);
			} else{
				printf("Consumer thread terminated normally\n");
				fflush(stdout);
				return NULL;
			}
			if (returnval == 1){
				printf("Password found!\nWriting...\n");
				theBuffer.passfound = 1;
				writeOut(item, (*var).outputFile);
				free(item);
			} else{
				free(item);
			}
		}
	}
	printf("Consumer thread terminated normally\n");
	fflush(stdout);
	return NULL;
}
//---------------------------------------
char* getWord()
// Gets a word from the global buffer, with all the necessary locks and conditions
{
	// lock mutex to access global buffer
	pthread_mutex_lock(&theBuffer.m);
	if(!theBuffer.pdone){
		while(theBuffer.occupied <= 0 && !theBuffer.pdone){
			pthread_cond_wait(&theBuffer.more, &theBuffer.m);
		} if (theBuffer.occupied <= 0 && !theBuffer.pdone){
			printf("CRITICAL ERROR!!\n");
			exit(-1);
		}
	} else if(theBuffer.occupied <= 0){
		return NULL;
	}
	
	char* item = malloc( sizeof(char) * 50 );
	strcpy(item, theBuffer.buffer[theBuffer.nextout]);
	theBuffer.nextout++;
	if (theBuffer.nextout == SIZE){
		theBuffer.nextout = 0;
	}
	theBuffer.occupied--;
	pthread_cond_signal(&theBuffer.less);
	pthread_mutex_unlock(&theBuffer.m);
	return item;
}
//----------------------------------------
int consume(char** item, char* HASH)
// Takes item and checks it against the password hash, adding minor changes along the way
// Anytime a character change function is called, check its hash. Whenever incNum is called, check the return val
{
	//printf("item on consume() = %s\n", *item);
	char* gpig;									// a duplicate string to ensure <item> doesnt get modified
	char* gpig2 = malloc( sizeof(char) * 50 );  // extra char* to copy gpig before gpig gets free()'dle out.tx
	char* incNumret; // Gets passed to incNum so that a successful string has a place to be stored
	int done = 0;
	int ret;
	
	// First, test plain string
	ret = hashVal(*item, HASH);
	if (ret == 1){
		free(gpig2);
		//printf("return 1 from consume\n");
		return 1;
	}
	// Next, increment from 0 to 9
	gpig = incNum(*item, HASH, &incNumret);
	if (gpig == NULL){
		free(gpig2);
		free(*item);
		*item = incNumret;
		return 1;
	}
	// If this doesnt work, change "i"'s to "!", then increment
	gpig = iToexc(*item);
	ret = hashVal(gpig, HASH);
	if (ret == 1){
		free(gpig2);
		free(*item);
		*item = gpig;
		return 1;
	}
	strcpy(gpig2, gpig);
	free(gpig);
	gpig = incNum(gpig2, HASH, &incNumret);
	if (gpig == NULL){
		free(gpig2);
		free(*item);
		*item = incNumret;
		return 1;
	}
	// Next, change l to 1, then increment
	gpig = lTo1(*item);
	ret = hashVal(gpig, HASH);
	if (ret == 1){
		free(gpig2);
		free(*item);
		*item = gpig;
		return 1;
	}
	strcpy(gpig2, gpig);
	free(gpig);
	gpig = incNum(gpig2, HASH, &incNumret);
	if (gpig == NULL){
		free(gpig2);
		free(*item);
		*item = incNumret;
		return 1;
	}
	
	// "o" to "0"
	gpig = oTo0(*item);
	ret = hashVal(gpig, HASH);
	if (ret == 1){
		free(gpig2);
		free(*item);
		*item = gpig;
		return 1;
	}
	strcpy(gpig2, gpig);
	free(gpig);
	gpig = incNum(gpig2, HASH, &incNumret);
	if (gpig == NULL){
		free(gpig2);
		free(*item);
		*item = incNumret;
		return 1;
	}
	
	// Start doing combinations
	gpig = iToexc(*item);
	strcpy(gpig2, gpig);
	free(gpig);
	gpig = lTo1(gpig2);
	ret = hashVal(gpig, HASH);
	if (ret == 1){
		free(gpig2);
		free(*item);
		*item = gpig;
		return 1;
	}
	strcpy(gpig2, gpig);
	free(gpig);
	gpig = incNum(gpig2, HASH, &incNumret);
	if (gpig == NULL){
		free(gpig2);
		free(*item);
		*item = incNumret;
		return 1;
	}
	
	gpig = oTo0(gpig2);
	ret = hashVal(gpig, HASH);
	if (ret == 1){
		free(gpig2);
		free(*item);
		*item = gpig;
		return 1;
	}
	strcpy(gpig2, gpig);
	free(gpig);
	gpig = incNum(gpig, HASH, &incNumret);
	if (gpig == NULL){
		free(gpig2);
		free(*item);
		*item = incNumret;
		return 1;
	}
	
	// Try a different combination
	gpig = oTo0(*item);
	strcpy(gpig2, gpig);
	free(gpig);
	gpig = lTo1(gpig2);
	ret = hashVal(gpig, HASH);
	if (ret == 1){
		free(gpig2);
		free(*item);
		*item = gpig;
		return 1;
	}
	strcpy(gpig2, gpig);
	free(gpig);
	gpig = incNum(gpig2, HASH, &incNumret);
	if (gpig == NULL){
		free(gpig2);
		free(*item);
		*item = incNumret;
		return 1;
	}

	// Next
	gpig = lTo1(*item);
	strcpy(gpig2, gpig);
	free(gpig);
	gpig = oTo0(gpig2);
	ret = hashVal(gpig, HASH);
	if (ret == 1){
		free(gpig2);
		free(*item);
		*item = gpig;
		return 1;
	}
	strcpy(gpig2, gpig);
	free(gpig);
	gpig = incNum(gpig2, HASH, &incNumret);
	if (gpig == NULL){
		free(gpig2);
		free(*item);
		*item = incNumret;
		return 1;
	}
	
	// Last combination
	gpig = iToexc(*item);
	strcpy(gpig2, gpig);
	free(gpig);
	gpig = oTo0(gpig2);
	ret = hashVal(gpig, HASH);
	if (ret == 1){
		free(gpig2);
		free(*item);
		*item = gpig;
		return 1;
	}
	strcpy(gpig2, gpig);
	free(gpig);
	gpig = incNum(gpig2, HASH, &incNumret);
	if (gpig == NULL){
		free(gpig2);
		free(*item);
		*item = incNumret;
		return 1;
	}
	
	
	// End and Cleanup
	free(gpig2);
	return 0;
}
//-----------------------------------------
char* iToexc(char* string)
// copies <string>, changes all instances of "i" in copy to "!", then returns copy
{
	char m; 
	int i, ret;
	int string_length = strlen(string);
	char* new_string = malloc( sizeof(char) * string_length + 1);

	for(i = 0; i < string_length; i++)
	{
		m = string[i];
		if(m == 'i')
		{
			new_string[i] = '!';
		}
		else{
			new_string[i] = m;
		}
	}
	new_string[i] = '\0';
	
	return new_string; 

}
//------------------------------------
char* lTo1(char* string)
// copies <string>, changes all instances of "l" in copy to "1", then returns copy
{
	char m; 
	int i, ret;
	int string_length = strlen(string);
	char* new_string = malloc( sizeof(char) * string_length + 1 );

	for(i = 0; i < string_length; i++)
	{
		m = string[i];
		if(m == 'l')
		{
			new_string[i] = '1';
		}
		else{
			new_string[i] = m;
		}
	}
	new_string[i] = '\0';
	
	return new_string; 
}
//-----------------------------------
char* oTo0(char* string)
// copies <string>, changes all instances of "o" in copy to "0", then returns copy
{
	char m; 
	int i, ret;
	int string_length = strlen(string);
	char* new_string = malloc(sizeof(char) * string_length + 1);

	for(i = 0; i < string_length; i++)
	{
		m = string[i];
		if(m == 'o')
		{
			new_string[i] = '0';
		}
		else{
			new_string[i] = m;
		}
	}
	new_string[i] = '\0';
	
	return new_string; 
}
//-------------------------------------
char* incNum(char* string, char* HASH, char** result)
// copies <string>, then appends a number, checks string hash, returning null and modifying <result> on a successful hash
{
	int i, ret;
	int string_length = strlen(string);
	char* new_string = malloc( string_length+2 * sizeof(char) );
	//strcpy(new_string, string);
	
	for (i = 0; i < 10; i++){
		sprintf(new_string, "%s%d", string, i);
		ret = hashVal(new_string, HASH);
		if (ret == 1){
			*result = new_string;
			return NULL;
		}
	}
	// If nothing is found, the string should be reset
	free(new_string);
	return string;
}
//--------------------------------------
int hashVal(char* arg, char* HASH)
// checks the hash of <arg> against <HASH>, returns 1 on match, 0 otherwise
{
	char string[65];
	sha_256_string(string, arg, sizeof(char) * strlen(arg));
	int ret = strcmp(string, HASH);
	//printf("Hash for word %s is %s\nHASH is %s\n\n", arg, string, HASH);
	//fflush(stdout);
	//fflush(stdout);
	if (ret == 0){
		//printf("return 1 from hashVal\n");
		return 1;
	}
	return 0;
}
//---------------------------------------
void writeOut(char* answer, char* filename)
// prints <answer> to file with name <filename>, terminates entire program on unsuccessful fopen() or if user does not wish to open file
{
	//printf("final answer = %s\n", answer);
	FILE* testfile = fopen(filename, "r");
	if (testfile != NULL){
		printf("File %s already exists. Overwrite? <y/n>\n", filename);
		fflush(stdout);
		char ans;
		scanf("%c", &ans);
		if (ans != 'y'){
			printf("Terminating...\n");
			fclose(testfile);
			exit(1);
		}
		fclose(testfile);
	}
	FILE* outfile = fopen(filename, "w");
	fprintf(outfile, "%s", answer);

}