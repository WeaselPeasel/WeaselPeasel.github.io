#include "sha-256.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main()
{
	char* string = "acac!!n9";
	char buffer[65];
	int len = (int)strlen(string);
	sha_256_string(buffer, string, strlen(string));

	FILE* outfile = fopen("password1.txt", "w");
	fprintf(outfile, "%s\n%s", buffer, string);

	return 0;
}
