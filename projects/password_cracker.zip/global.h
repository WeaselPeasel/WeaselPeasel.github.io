#ifndef _GLOBAL_
#define _GLOBAL_
#include <pthread.h>
#include <sys/types.h>
#include <stdlib.h>
#include <stdio.h>
/*
 * producer.h
 * Programmer: Caleb Braddick, et al.
 * Summary: declares functions that need to be used by producer thread in program
 */
// Define Global Variables
#define SIZE 10000
struct Buffer{
	char** buffer;
	int occupied;			// tracks the current size of the buffer
	int nextin;				// keeps track of the indices of the head and tail of the queue
	int nextout;			// 
	int pdone;				// Tells whether producer is finished 
	int passfound;			// Tells whether the password has been found
	pthread_mutex_t m;		
	pthread_mutex_t fin;	// Locks when producer finishes reading file or when consumer finds password match
	pthread_cond_t more;
	pthread_cond_t less;
};
struct Buffer theBuffer;

#endif