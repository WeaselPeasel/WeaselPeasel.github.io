#!/bin/bash
./bigBoi cain.txt password1.txt out.txt 2
#<name>   <dict>    <password>   <output>  <# threads>
