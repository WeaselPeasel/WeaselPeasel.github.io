#include "global.h"
#include "sha-256.h"
#include <string.h>
/*
 * consumer.h
 * Programmer: Caleb Braddick, et al.
 * Summary: Declares struct and functions used by consumer threads
 */
struct Consumer{
	char* HASH;
	char* outputFile;
};
typedef struct Consumer Consumer;

void* Run(void* arg);
char* getWord();
int consume(char** item, char* HASH);
char* incNum(char* string, char*HASH, char** result);
char* iToexc(char* string);
char* lTo1(char* string);
char* oTo0(char* string);

int hashVal(char* arg, char* HASH);

void writeOut(char* answer, char* fileName);